<style>
	.logo {

    
}
span{
    text-indent: 0.1cm;
    color: white;
    text-align:center;
    font-size:22px;;
}
.blue {
  background-color: #08245b;
}
.logout{
  color:white;
  padding-top:20px;
  position: absolute;
  top:-10px;
}
.logout:hover{
  color:#993333;
}

</style>

<nav class="navbar navbar-dark blue fixed-top " style="padding:0;">
  <div class="container-fluid mt-2 mb-2">
  	<div class="col-lg-12">
  		<div class="col-md-1 float-left" style="display: flex;">
  			<div class="logo">
              <img src="assets/img/team/chmsclogo.png" width="40" height="40" />
              
  			</div>
              <span>One</span> <span>Tap</span> <span>Portfolio</span>

  		</div>
	  	<div class="col-md-2 float-right">
	  		<a href="ajax.php?action=logout" class="logout"><?php echo $_SESSION['login_name'] ?> <i class="fa fa-power-off"></i></a>
	    </div>
    </div>
  </div>
  
</nav>