<?php 

$conn= new mysqli('localhost','u693593446_user','@@Njmv1OoC^0','u693593446_fms_db')or die("Could not connect to mysql".mysqli_error($con));
